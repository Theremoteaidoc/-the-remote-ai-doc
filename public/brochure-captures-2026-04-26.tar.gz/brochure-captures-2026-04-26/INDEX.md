# SeaScope Brochure Captures — 2026-04-26

Fresh UI captures for the marketing brochure. All shots are at retina
quality (2× device-pixel ratio for desktop, native for mobile).
Hub captures use real OneCare pilot data (5 vessels, 3 cases).

## Hub captures (desktop, 1440×900 @ 2×)

| File | Purpose | Brochure page |
|---|---|---|
| `hub-0-admin-picker.png` | "Admin preview · pick a view" — three-mode role picker | Page 4-5 (The Platform spread) — visual proof that one product serves three roles |
| `hub-1-fleet-admin.png` | Fleet overview · 5 vessels · 3 cases · PEME compliance radar | **Page 8-9 hero (Cargo Solutions spread)** — the money shot |
| `hub-1-fleet-admin-fullpage.png` | Same but with full vessel grid scrolled | Backup / alternative for same spread |
| `hub-2-physician.png` | Shore Physician queue · CRITICAL case waiting · Active/All/Done filters | Page 8-9 secondary (Cargo Solutions spread) — physician hub story |
| `hub-2-physician-fullpage.png` | Same | Backup |
| `hub-2-physician-case-open.png` | Same as queue (click didn't open detail — still good as queue shot) | Backup for Cargo spread |
| `hub-3-officer.png` | Ship Officer view · "+ New Medical Case" CTA · 3 active cases (1 doctor-claimed, 2 doctor-replied) | Page 8-9 tertiary — officer-side story |
| `hub-3-officer-fullpage.png` | Same | Backup |

## Mobile demo captures (iPhone 14 + iPhone Pro Max)

| File | Purpose | Brochure page |
|---|---|---|
| `mobile-iphone-14-1-pick.png` | Vessel picker · 5 cards · "Run a real maritime case" hero | **Page 6-7 (CDS for Physicians) inset** — phone in cinematic context |
| `mobile-iphone-14-2-brief.png` | Patient brief panel · vitals + allergies + meds | Page 6-7 alternate |
| `mobile-iphone-14-3-reveal.png` | Engine reveal · animated step-by-step · TIMI/GRACE calculators | Page 10-11 (Inside the Engine) inset |
| `mobile-iphone-14-4-result.png` | 5-card recommendation · diagnosis / now / meds / evac / why-different | Page 6-7 alternate or page 12 (Real Case) inset |
| `mobile-iphone-pro-max-*.png` | Same flow at 414×896 viewport | Use whichever frames better in the layout |

## Recommended brochure page → capture map

```
PAGE 4-5  THE PLATFORM SPREAD          hub-0-admin-picker.png
PAGE 6-7  CDS FOR PHYSICIANS           mobile-iphone-14-1-pick.png  +
                                       mobile-iphone-14-4-result.png
PAGE 8-9  CARGO SOLUTIONS              hub-1-fleet-admin.png  (hero)
                                       hub-3-officer.png  (officer-side)
                                       hub-2-physician.png  (physician-side)
PAGE 10-11 INSIDE THE ENGINE           mobile-iphone-14-3-reveal.png
                                       (plus older showcase-*.png from
                                       /home/seascope-cds/video/seascope-walkthrough/out/)
PAGE 12   REAL CASE (Voyager)          ocean-aerial.jpg as bg, no UI shot
                                       (numbers do the work)
```

## Notes

- The Hub captures use **real OneCare pilot data** — vessels, cases, PEME
  compliance metrics are all live numbers. Names are fine for marketing
  use (OneCare is the publicly-named pilot partner).
- The CASE-2026-0003 critical case ("Bosun Juan...") is realistic seed
  data. If you'd rather de-identify before sending, edit in the design
  tool.
- The mobile demo shots use the canned vessel scenarios from
  MobileDemoPreview.jsx — STEMI on Star of the Seas. All content is
  hand-curated and brochure-safe.
- The bottom-right "hanna@seascope.tech / Logout" header text in Hub
  captures can be cropped or replaced with a generic identifier in the
  brochure layout.
- For the older brand-styled UI shots, see also:
  /home/seascope-cds/video/seascope-walkthrough/out/showcase-*.png

## Source script

- `frontend/brochure-capture.mjs` — main capture (Hub + mobile demo)
- `frontend/brochure-physician-detail.mjs` — physician case-open attempt
